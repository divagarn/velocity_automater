#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, Point, Quaternion

class MoveForward:
    def __init__(self):
        rospy.init_node('move_forward')
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

    def move(self, num_moves):
        for i in range(num_moves):
            goal = MoveBaseGoal()
            goal.target_pose.header.frame_id = "base_link"
            goal.target_pose.header.stamp = rospy.Time.now()
            goal.target_pose.pose.position.x = 0.2
            goal.target_pose.pose.orientation.w = 1.0

            self.client.send_goal(goal)
            self.client.wait_for_server()
            self.client.wait_for_result()

if __name__ == '__main__':
    num_moves = int(input("How many times should I move forward by 0.5m each time? "))
    move_forward = MoveForward()
    move_forward.move(num_moves)

