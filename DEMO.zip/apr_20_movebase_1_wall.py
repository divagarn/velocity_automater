import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class WallFollower:
    def __init__(self):
        self.wall_distance = 0.45 # set the desired distance to the wall
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.scan_sub = rospy.Subscriber('/scan', LaserScan, self.scan_callback)

    def scan_callback(self, scan_data):
        # find the distance to the nearest wall
        nearest_wall_distance = min(scan_data.ranges)
        # calculate the error between the desired distance and the actual distance
        error = nearest_wall_distance - self.wall_distance
        # find the orientation of the wall relative to the robot's current orientation
        wall_orientation = scan_data.ranges.index(min(scan_data.ranges))
        # adjust the robot's orientation and position accordingly
        twist_msg = Twist()
        twist_msg.angular.z = -0.5 * wall_orientation # adjust the robot's orientation
        twist_msg.linear.x = 0.1 * error # adjust the robot's position
        self.cmd_vel_pub.publish(twist_msg)

        # stop the robot if it is aligned parallel to the wall
        if abs(error) < 0.05 and abs(wall_orientation) < 10:
            twist_msg.linear.x = 0
            twist_msg.angular.z = 0
            self.cmd_vel_pub.publish(twist_msg)

if __name__ == '__main__':
    rospy.init_node('wall_follower')
    wf = WallFollower()
    rospy.spin()

