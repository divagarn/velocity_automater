#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, Point, Quaternion

if __name__ == '__main__':
    rospy.init_node('move_forward_multiple_times')
    
    # Initialize the MoveBase action client
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
    client.wait_for_server()
    
    # Create the navigation goal
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "base_link"
    goal.target_pose.header.stamp = rospy.Time.now()
    goal.target_pose.pose.position.x = 0.5
    goal.target_pose.pose.orientation.w = 1.0
    
    # Send the navigation goal to the MoveBase node multiple times
    for i in range(5):
        client.send_goal(goal)
        client.wait_for_result()
    
    rospy.loginfo("Completed running forward 0.5m for 5 times.")

