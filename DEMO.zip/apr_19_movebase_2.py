#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, Point, Quaternion
from tf.transformations import quaternion_from_euler

class MoveForward:
    def __init__(self):
        rospy.init_node('move_forward')
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

    def move(self, num_moves):
        for i in range(num_moves):
            # Send the forward goal
            goal = MoveBaseGoal()
            goal.target_pose.header.frame_id = "base_link"
            goal.target_pose.header.stamp = rospy.Time.now()
            goal.target_pose.pose.position.x = 0.2
            goal.target_pose.pose.orientation.w = 1.0

            self.client.send_goal(goal)
            self.client.wait_for_result()

            # Prompt the user to choose whether to rotate right or continue moving forward
            choice = input("Enter 'F' to move forward or 'R' to rotate right: ")

            if choice == 'F':
                continue
            elif choice == 'R':
                goal = self.get_right_rotation_goal()
                self.client.send_goal(goal)
                self.client.wait_for_result()
            else:
                print("Invalid choice. Continuing to move forward.")

    def get_right_rotation_goal(self):
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "base_link"
        goal.target_pose.header.stamp = rospy.Time.now()
        q = quaternion_from_euler(0, 0, -1.5708) # 90-degree right rotation
        goal.target_pose.pose.orientation = Quaternion(*q)
        return goal

if __name__ == '__main__':
    num_moves = int(input("How many times should I move forward by 0.5m each time? "))
    move_forward = MoveForward()
    move_forward.move(num_moves)

