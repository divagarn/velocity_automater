#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, Point, Quaternion
from tf.transformations import quaternion_from_euler

class MoveForward:
    def __init__(self):
        rospy.init_node('move_forward')
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

    def move_forward(self, num_moves, goal_amount):
        for i in range(num_moves):
            goal = self.get_forward_goal(goal_amount)
            self.client.send_goal(goal)
            self.client.wait_for_result()

    def move_right_rotation(self, num_moves, goal_amount):
        for i in range(num_moves):
            goal = self.get_right_rotation_goal(goal_amount)
            self.client.send_goal(goal)
            self.client.wait_for_result()

    def get_forward_goal(self, goal_amount):
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "base_link"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = goal_amount
        goal.target_pose.pose.orientation.w = 1.0
        return goal

    def get_right_rotation_goal(self, goal_amount):
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "base_link"
        goal.target_pose.header.stamp = rospy.Time.now()
        q = quaternion_from_euler(0, 0, -1.5708) # 90-degree right rotation
        q_rot = quaternion_from_euler(0, 0, goal_amount)
        q_new = quaternion_multiply(q, q_rot)
        goal.target_pose.pose.orientation = Quaternion(*q_new)
        return goal

if __name__ == '__main__':
    move_forward = MoveForward()
    input_str = input("Enter goal type (F/R), goal amount, and number of times to perform the goal (e.g. 0.5 F 5): ")
    input_list = input_str.split()

    if len(input_list) != 3:
        print("Invalid input. Please enter 'F' or 'R' as the goal type, a numerical goal amount, and a numerical number of times to perform the goal.")
    elif input_list[0] == 'F':
        goal_type = "forward"
        goal_amount = float(input_list[1])
        num_moves = int(input_list[2])
        move_forward.move_forward(num_moves, goal_amount)
        print("Performed {} goal of {} meters for {} times.".format(goal_type, goal_amount, num_moves))
    elif input_list[0] == 'R':
        goal_type = "right rotation"
        goal_amount = float(input_list[1])
        num_moves = int(input_list[2])
        move_forward.move_right_rotation(num_moves, goal_amount)
        print("Performed {} goal of {} degrees for {} times.".format(goal_type, goal_amount, num_moves))
    else:
        print("Invalid input. Please enter 'F' or 'R' as the goal type.")

